Installation:

1. Move Unread-Messages.widget to your Ubersicht widgets folder.
2. Enjoy!
