Installation:

1. Move mail-and-messages.widget to your Ubersicht widgets folder.
2. Enjoy!
